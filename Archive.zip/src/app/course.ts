export class Course {
    constructor(
        public Id?: number,
        public Subject?: string,
        public Instructor?: string,
        ) {}
}
