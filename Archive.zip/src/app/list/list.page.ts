import { Student } from './../student';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage {
  allStudents: Student[] = [];

  constructor(private dataSrv: DataService) {
    // get the data from the service
    dataSrv.getStudents().subscribe(res => {
      console.log('finish getting data');
      this.allStudents = res;
    });

    console.log('data loaded', this.allStudents);
  }

  showDetails(selStudent : Student){
    if(!selStudent.Courses){
      selStudent.Courses = [];
    }
    selStudent.Courses.push('110');
    this.dataSrv.updateStudent(selStudent);
  }

  // add back when alpha.4 is out
  // navigate(item) {
  //   this.router.navigate(['/list', JSON.stringify(item)]);
  // }
}
