import { DataService } from './../data.service';
import { Student } from './../student';
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class HomePage {
  studentModel: Student = new Student();

  constructor(private dataSrv: DataService) {}

  registerStudent() {
    console.log(this.studentModel);
    this.dataSrv.saveStudent(this.studentModel); // save

    // clear
    this.studentModel = new Student();
  }
}
