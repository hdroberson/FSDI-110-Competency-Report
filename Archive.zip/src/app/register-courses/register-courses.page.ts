import { Component, OnInit } from '@angular/core';
import { Course } from '../course';
import { DataService } from '../data.service';

@Component({
  selector: 'app-register-courses',
  templateUrl: './register-courses.page.html',
  styleUrls: ['./register-courses.page.scss'],
})
export class RegisterCoursesPage implements OnInit {

  courseModel : Course = new Course();

  constructor(private dataSrv : DataService) { }

  registerCourse() {
    this.dataSrv.saveCourse(this.courseModel); // save current course
    this.courseModel = new Course(); // clear the capture form
  }

  ngOnInit() {
  }

}
